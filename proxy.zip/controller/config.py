from pathlib import Path
from pydantic_settings import BaseSettings
from typing import Optional


class Settings(BaseSettings):
    # Application
    app_name: str = "NekoProxy Controller"
    debug: bool = False

    # Server
    host: str = "0.0.0.0"
    port: int = 8000

    # Database
    database_url: str = "sqlite:///./nekoproxy.db"

    # Agent settings
    heartbeat_interval: int = 30  # seconds
    heartbeat_timeout: int = 90   # seconds before marking unhealthy

    # Config versioning
    config_version: int = 1

    # Stats cleanup
    stats_retention_days: int = 30

    # Web UI
    templates_dir: Path = Path(__file__).parent / "web" / "templates"
    static_dir: Path = Path(__file__).parent / "web" / "static"

    class Config:
        env_prefix = "NEKO_"
        env_file = ".env"


settings = Settings()
