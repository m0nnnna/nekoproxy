# Shared models and utilities for proxy service
